package com.revature.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.revature.beans.Employee;

@Repository
public interface EmployeeRepo extends CrudRepository<Employee, Integer> {
	
	List<Employee> findByName(String name);
	List<Employee> findByNameAndDuration(String name, int duration);
	List<Employee> findByDuration(int duration);

}
