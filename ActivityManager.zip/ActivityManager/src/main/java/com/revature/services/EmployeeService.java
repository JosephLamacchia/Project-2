package com.revature.services;

import java.util.List;

import com.revature.beans.Employee;

public interface EmployeeService {
	
	public Employee addEmployee(Employee a);
	public Employee getEmployee(int id);
	public List<Employee> getAllEmployees();
	public Employee updateEmployee(Employee change);
	public boolean deleteEmployee(int id);
	public boolean deleteEmployee2(int id);
	public List<Employee> getEmployee(String name);
	public List<Employee> getEmployee(String name, int duration);
	public List<Employee> getEmployeeByDuration(int duration);

}
