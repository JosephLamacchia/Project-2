export class Taskpriority {

    id_taskpriority: number;
    name_taskpriority: string;

    constructor (id_taskpriority:number, name_taskpriority:string) {
        this.id_taskpriority = id_taskpriority;
        this.name_taskpriority = name_taskpriority;

    }
}