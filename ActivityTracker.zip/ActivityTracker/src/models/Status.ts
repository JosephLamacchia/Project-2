export class Status {

    id_status: number;
    name_status: string;

    constructor (id_status: number, name_status:string) {
        this.id_status = id_status;
        this.name_status = name_status;
    }

}