export class TaskType {

    id_tasktype: number;
    name_tasktype: string;

    constructor (id_tasktype:number, name_tasktype:string) {
        this.id_tasktype = id_tasktype;
        this.name_tasktype = name_tasktype;

    }
}